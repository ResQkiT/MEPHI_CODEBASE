#pragma once
#define true 1
#define false 0
#define bool int