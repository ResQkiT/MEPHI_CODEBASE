echo Cleaning directory
rm *.o