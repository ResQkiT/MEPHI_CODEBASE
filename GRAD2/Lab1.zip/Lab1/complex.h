#pragma once
#include "fieldinfo.h"
FieldInfo *getComplexImplementationInstance();
