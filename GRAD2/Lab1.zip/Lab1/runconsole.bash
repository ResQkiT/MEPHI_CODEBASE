make main
./main
bash clean.bash