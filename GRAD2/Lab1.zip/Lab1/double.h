#pragma once
#include "fieldinfo.h"

FieldInfo *getDoubleImplementationInstance();
